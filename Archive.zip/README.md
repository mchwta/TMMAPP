# Daily Moments

This example is part of the Ionic React course.

## Links

 * [Firebase: Get Started](https://firebase.google.com/docs/web/setup)
 * [Firebase Authentication](https://firebase.google.com/docs/auth)
 * [Cloud Firestore](https://firebase.google.com/docs/firestore)
